(function () {
  var views = document.querySelectorAll('.view');
  var links = document.querySelectorAll('[data-nav]');

  function go() {
    var h = (location.hash || '#home').slice(1);
    if (h !== 'gallery') h = 'home';
    views.forEach(function (v) { v.hidden = v.dataset.view !== h; });
    links.forEach(function (a) {
      var on = a.dataset.nav === h;
      a.classList.toggle('on', on);
      if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    window.scrollTo(0, 0);
  }
  window.addEventListener('hashchange', go);
  go();

  // The photo is the secret door to the gallery
  function openGallery() { location.hash = '#gallery'; }
  document.getElementById('photo').addEventListener('click', openGallery);
  document.getElementById('open').addEventListener('click', openGallery);

  // Typing effect
  var el = document.getElementById('typed');
  var words = ['a soccer fan', 'a Spider-Man fan', 'a movie-night regular', 'a proud fan of both worlds'];
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!reduce) {
    var p = 0, i = words[0].length, del = true;
    (function tick() {
      var w = words[p];
      i += del ? -1 : 1;
      el.textContent = w.slice(0, i);
      var d = del ? 45 : 90;
      if (!del && i === w.length) { del = true; d = 1600; }
      else if (del && i === 0) { del = false; p = (p + 1) % words.length; d = 350; }
      setTimeout(tick, d);
    })();
  }

  // Lightbox
  var lb = document.getElementById('lb');
  var lbi = document.getElementById('lbi');
  document.querySelectorAll('.card').forEach(function (c) {
    c.addEventListener('click', function () {
      var img = c.querySelector('img');
      lbi.src = img.currentSrc || img.src;
      lbi.alt = img.alt;
      if (lb.showModal) lb.showModal(); else lb.setAttribute('open', '');
    });
  });
  document.getElementById('lbx').addEventListener('click', function () { lb.close(); });
  lb.addEventListener('click', function (e) { if (e.target === lb) lb.close(); });
})();

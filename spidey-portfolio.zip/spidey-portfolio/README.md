# My Portfolio · Soccer & Spider-Man

A small personal portfolio. The home page shows a round photo with a tap hint. Tapping it opens a Spider-Man gallery with three pictures, and each picture opens larger. Plain HTML, CSS and JavaScript, with no build step and no password.

## Files

```
index.html          Both views (Home and Gallery) in one page
css/style.css       Styling (light and dark mode)
js/script.js        View switching, typing effect, image viewer
assets/hero.jpg     The round photo on the home page
assets/spidey-*.jpg The three gallery pictures
```

## Make it yours

- Replace `Your Name` in `index.html`.
- Swap any picture by replacing the file in `assets/` with one of the same name.
- Edit the typed phrases in `js/script.js` (the `words` list).

## Publish free on GitHub Pages (no password for visitors)

1. Create a new **public** repository on GitHub, for example `my-portfolio`.
2. Upload every file here, keeping the folders. Make sure `index.html` is at the top level.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, pick `main` and `/ (root)`, then **Save**.
5. After a minute or two the site is live at `https://YOUR-USERNAME.github.io/my-portfolio/`. Share that link. Anyone can open it with one click.

Only use pictures you have the right to share publicly.
